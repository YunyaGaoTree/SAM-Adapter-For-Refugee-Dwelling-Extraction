# Copyright (c) OpenMMLab. All rights reserved.
from .data_parallel import MPSDataParallel

__all__ = ['MPSDataParallel']
